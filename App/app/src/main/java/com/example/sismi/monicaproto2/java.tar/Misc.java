package com.example.sismi.monicaproto2;

public class Misc {
    public static String newline = System.getProperty("line.separator");
}
