package com.example.sismi.monicaproto2;

public enum ProtocolConstants {
	ERROR,SEND_TXT, SEND_POS, SEND_IMG, SEND_AUDIO, CMD_DONE, CLOSE;
}
